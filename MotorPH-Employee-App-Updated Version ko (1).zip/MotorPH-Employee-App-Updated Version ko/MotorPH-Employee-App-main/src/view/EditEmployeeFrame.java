package view;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.Employee;
import model.EmployeeDatabase;

public class EditEmployeeFrame extends JFrame {
    private JTable editTable;
    private DefaultTableModel tableModel;
    private EmployeeMainFrame parentFrame;

    public EditEmployeeFrame(EmployeeMainFrame parent) {
        this.parentFrame = parent;
        setTitle("Edit Employee CSV Data");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(parent);
        
        initializeComponents();
        loadData();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout());

        // Header panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UIConstants.PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(getWidth(), 50));
        
        JLabel titleLabel = new JLabel("Edit Employee Data");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(new EmptyBorder(15, 20, 15, 20));
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Table setup
        String[] columns = {
            "Employee No.", "First Name", "Last Name", "Contact Info", 
            "Position", "Department", "Birthday", "SSS No.", 
            "PhilHealth No.", "TIN", "Pag-IBIG No."
        };
        
        tableModel = new DefaultTableModel(columns, 0);
        editTable = new JTable(tableModel);
        editTable.setRowHeight(25);
        editTable.setFont(new Font("SansSerif", Font.PLAIN, 12));
        editTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));

        JScrollPane scrollPane = new JScrollPane(editTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        JButton saveButton = new JButton("Save Changes");
        JButton cancelButton = new JButton("Cancel");
        JButton addRowButton = new JButton("Add Row");
        JButton deleteRowButton = new JButton("Delete Row");

        saveButton.addActionListener(e -> saveChanges());
        cancelButton.addActionListener(e -> dispose());
        addRowButton.addActionListener(e -> addNewRow());
        deleteRowButton.addActionListener(e -> deleteSelectedRow());

        buttonPanel.add(addRowButton);
        buttonPanel.add(deleteRowButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        add(headerPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadData() {
        tableModel.setRowCount(0);
        List<Employee> employees = EmployeeDatabase.getEmployees();
        for (Employee emp : employees) {
            Object[] rowData = {
                emp.getEmployeeNumber(),
                emp.getFirstName(),
                emp.getLastName(),
                emp.getContactInfo(),
                emp.getPosition(),
                emp.getDepartment(),
                emp.getBirthday().toString(),
                emp.getSssNumber(),
                emp.getPhilhealthNumber(),
                emp.getTinNumber(),
                emp.getPagibigNumber()
            };
            tableModel.addRow(rowData);
        }
    }

    private void addNewRow() {
        Object[] newRow = {"", "", "", "", "", "", "", "", "", "", ""};
        tableModel.addRow(newRow);
    }

    private void deleteSelectedRow() {
        int selectedRow = editTable.getSelectedRow();
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this employee record?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                tableModel.removeRow(selectedRow);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                "Please select a row to delete.",
                "No Selection",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void saveChanges() {
        try {
            // Clear current employees
            EmployeeDatabase.clearEmployees();
            
            // Validate and save each row
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String empNum = (String) tableModel.getValueAt(i, 0);
                String firstName = (String) tableModel.getValueAt(i, 1);
                String lastName = (String) tableModel.getValueAt(i, 2);
                String contactInfo = (String) tableModel.getValueAt(i, 3);
                String position = (String) tableModel.getValueAt(i, 4);
                String department = (String) tableModel.getValueAt(i, 5);
                String birthdayStr = (String) tableModel.getValueAt(i, 6);
                String sssNumber = (String) tableModel.getValueAt(i, 7);
                String philhealthNumber = (String) tableModel.getValueAt(i, 8);
                String tinNumber = (String) tableModel.getValueAt(i, 9);
                String pagibigNumber = (String) tableModel.getValueAt(i, 10);

                // Skip empty rows
                if (empNum == null || empNum.trim().isEmpty()) {
                    continue;
                }

                // Validate required fields
                if (firstName == null || firstName.trim().isEmpty() ||
                    lastName == null || lastName.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this,
                        "Row " + (i + 1) + ": First Name and Last Name are required.",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Parse birthday
                LocalDate birthday;
                try {
                    birthday = LocalDate.parse(birthdayStr);
                } catch (DateTimeParseException e) {
                    JOptionPane.showMessageDialog(this,
                        "Row " + (i + 1) + ": Invalid date format. Use YYYY-MM-DD.",
                        "Date Format Error",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Employee employee = new Employee(
                    empNum.trim(),
                    firstName.trim(),
                    lastName.trim(),
                    contactInfo != null ? contactInfo.trim() : "",
                    position != null ? position.trim() : "",
                    department != null ? department.trim() : "",
                    birthday,
                    sssNumber != null ? sssNumber.trim() : "",
                    philhealthNumber != null ? philhealthNumber.trim() : "",
                    tinNumber != null ? tinNumber.trim() : "",
                    pagibigNumber != null ? pagibigNumber.trim() : ""
                );

                EmployeeDatabase.addEmployeeDirectly(employee);
            }

            // Save all changes to CSV
            EmployeeDatabase.saveAllEmployees();

            JOptionPane.showMessageDialog(this,
                "Changes saved successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);

            // Refresh parent frame
            parentFrame.refreshTable();
            dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error saving changes: " + e.getMessage(),
                "Save Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}