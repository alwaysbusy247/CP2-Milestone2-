package model;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDatabase {
    private static final String EMPLOYEE_FILE_NAME = "employees.csv";
    private static final File EMPLOYEE_FILE = resolveEmployeeFile();
    private static final List<Employee> employees = new ArrayList<>();
    private static boolean isInitialized = false;

    private static File resolveEmployeeFile() {
        File workingDirFile = new File(EMPLOYEE_FILE_NAME);
        System.out.println("Working directory: " + new File(".").getAbsolutePath());
        System.out.println("EMPLOYEE CSV path: " + workingDirFile.getAbsolutePath());
        System.out.println("EMPLOYEE file exists? " + workingDirFile.exists());
        return workingDirFile;
    }

    private static void initialize() {
        if (!isInitialized) {
            loadEmployees();
            isInitialized = true;
        }
    }

    public static List<Employee> getEmployees() {
        initialize();
        return new ArrayList<>(employees);
    }

    public static Employee findByEmployeeNumber(String employeeNumber) {
        initialize();
        if (employeeNumber == null) return null;
        return employees.stream()
                .filter(e -> employeeNumber.equals(e.getEmployeeNumber()))
                .findFirst()
                .orElse(null);
    }

    public static void addEmployee(Employee employee) {
        initialize();
        if (employee == null || findByEmployeeNumber(employee.getEmployeeNumber()) != null) {
            throw new IllegalArgumentException("Employee number already exists or input is null");
        }
        employees.add(employee);
        saveEmployees();
    }

    public static void addEmployeeDirectly(Employee employee) {
        initialize();
        if (employee != null) {
            employees.add(employee);
        }
    }

    public static void updateEmployee(Employee employee) throws IOException {
        initialize();
        if (employee == null) return;
        Employee existing = findByEmployeeNumber(employee.getEmployeeNumber());
        if (existing != null) {
            employees.remove(existing);
            employees.add(employee);
            saveEmployees();
        }
    }

    public static void deleteEmployee(String employeeNumber) throws IOException {
        initialize();
        Employee employee = findByEmployeeNumber(employeeNumber);
        if (employee != null) {
            employees.remove(employee);
            saveEmployees();
        }
    }

    public static void clearEmployees() {
        initialize();
        employees.clear();
    }

    public static void saveAllEmployees() {
        saveEmployees();
    }

    public static void loadEmployees() {
        employees.clear();

        if (!EMPLOYEE_FILE.exists()) {
            System.out.println("employees.csv not found at: " + EMPLOYEE_FILE.getAbsolutePath());
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(EMPLOYEE_FILE))) {
            String line;
            boolean isFirstLine = true;

            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }

                String[] parts = line.split(",", -1);
                if (parts.length < 11) continue;

                try {
                    Employee emp = new Employee(
                        parts[0].trim(),
                        parts[1].trim(),
                        parts[2].trim(),
                        parts[3].trim(),
                        parts[4].trim(),
                        parts[5].trim(),
                        LocalDate.parse(parts[6].trim()),
                        parts[7].trim(),
                        parts[8].trim(),
                        parts[9].trim(),
                        parts[10].trim()
                    );
                    employees.add(emp);
                    System.out.println("Loaded: " + emp.getEmployeeNumber());
                } catch (Exception e) {
                    System.err.println("Error parsing line: " + line);
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading employee file: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("Total employees loaded: " + employees.size());
    }

    private static void saveEmployees() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(EMPLOYEE_FILE))) {
            writer.println("Employee Number,First Name,Last Name,Contact Info,Position,Department,Birthday,SSS Number,PhilHealth Number,TIN,Pag-IBIG Number");

            for (Employee emp : employees) {
                writer.printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s%n",
                    emp.getEmployeeNumber(),
                    emp.getFirstName(),
                    emp.getLastName(),
                    emp.getContactInfo(),
                    emp.getPosition(),
                    emp.getDepartment(),
                    emp.getBirthday(),
                    emp.getSssNumber(),
                    emp.getPhilhealthNumber(),
                    emp.getTinNumber(),
                    emp.getPagibigNumber()
                );
            }

            System.out.println("Saved employees to: " + EMPLOYEE_FILE.getAbsolutePath());

        } catch (IOException e) {
            System.err.println("Error saving employees: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
