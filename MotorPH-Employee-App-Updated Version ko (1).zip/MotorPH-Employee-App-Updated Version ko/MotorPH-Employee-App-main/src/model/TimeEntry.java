package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import model.TimeEntry;


public class TimeEntry {
    private final String employeeNumber;
    private final LocalDateTime timeIn;
    private LocalDateTime timeOut;

    public TimeEntry(String employeeNumber, LocalDateTime timeIn) {
        this.employeeNumber = employeeNumber;
        this.timeIn = timeIn;
    }

    public String getEmployeeNumber() { return employeeNumber; }
    public LocalDateTime getTimeIn() { return timeIn; }
    public LocalDateTime getTimeOut() { return timeOut; }

    public void setTimeOut(LocalDateTime timeOut) {
        this.timeOut = timeOut;
    }

    public double getHoursWorked() {
        if (timeOut == null) return 0;
        return java.time.Duration.between(timeIn, timeOut).toMinutes() / 60.0;
    }

    public String toCsvString() {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        return String.format("%s,%s,%s", 
            employeeNumber, 
            timeIn.format(formatter),
            timeOut != null ? timeOut.format(formatter) : "");
    }

    // Make sure this method is INSIDE the class
    public static TimeEntry fromCsvString(String csvLine) {
    String[] parts = csvLine.split(",", -1); // Keep empty trailing values

    // Validate minimum required fields
    if (parts.length < 2 || parts[0].isEmpty() || parts[1].isEmpty()) {
        System.err.println("Skipping invalid CSV line: " + csvLine);
        return null;
    }

    try {
        String employeeNumber = parts[0];
        LocalDateTime timeIn = LocalDateTime.parse(parts[1]);

        TimeEntry entry = new TimeEntry(employeeNumber, timeIn);

        if (parts.length > 2 && !parts[2].isEmpty()) {
            entry.setTimeOut(LocalDateTime.parse(parts[2]));
        } else {
            // Default fallback: set End Time same as Start Time
            entry.setTimeOut(timeIn);
        }

        return entry;
    } catch (Exception e) {
        System.err.println("Error parsing time entry: " + csvLine + " → " + e.getMessage());
        return null;
    }
}
}
