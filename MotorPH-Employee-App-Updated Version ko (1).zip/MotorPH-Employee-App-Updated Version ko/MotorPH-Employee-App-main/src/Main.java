import javax.swing.*;
import javax.swing.UIManager;
import javax.swing.SwingUtilities;
import model.EmployeeDatabase;
import model.TimeEntry;
import service.PayrollService;
import service.TimeTrackingService;
import view.EmployeeMainFrame;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        try {
            // Set system look and feel
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

            // Load employees data
            EmployeeDatabase.loadEmployees();

            // Load time tracking data
            TimeTrackingService.loadTimeEntries();

            // Debug: Print loaded entries to console
            for (TimeEntry entry : TimeTrackingService.getTimeEntries()) {
                System.out.println("Loaded: " + entry.getEmployeeNumber() + " → " +
                                   entry.getTimeIn() + " to " + entry.getTimeOut());
            }

            // Start the application
            SwingUtilities.invokeLater(() -> {
                try {
                    // Launch your main payroll window
                    EmployeeMainFrame mainFrame = new EmployeeMainFrame();
                    mainFrame.setVisible(true);

                    // Removed automatic launch of time entry table
                } catch (Exception e) {
                    showError("Failed to start application: " + e.getMessage());
                }
            });
        } catch (Exception e) {
            showError("Failed to initialize application: " + e.getMessage());
        }
    }

    public static void showTimeEntryTable() {
        JFrame frame = new JFrame("Employee Time Entries");
        frame.setSize(700, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        PayrollService.displayTimeEntryTable(panel);
        frame.setContentPane(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.toFront();
        frame.requestFocus();
    }

    private static void showError(String message) {
        JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
