package service;

import java.io.*;
import java.util.*;
import java.time.LocalDateTime;
import javax.swing.*;

import model.TimeEntry;
import service.PayrollService;

public class TimeTrackingService {
    private static final String TIME_ENTRIES_FILE_NAME = "time_entries.csv";
    private static final File TIME_ENTRIES_FILE = resolveTimeEntriesFile();
    private static List<TimeEntry> timeEntries = new ArrayList<>();

    private static File resolveTimeEntriesFile() {
        File file = new File(TIME_ENTRIES_FILE_NAME);
        System.out.println("TIME ENTRIES CSV path: " + file.getAbsolutePath());
        System.out.println("TIME ENTRIES file exists? " + file.exists());
        return file;
    }

    public static void loadTimeEntries() {
        timeEntries.clear();

        if (!TIME_ENTRIES_FILE.exists()) {
            System.out.println("time_entries.csv not found. Skipping load.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(TIME_ENTRIES_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    TimeEntry entry = TimeEntry.fromCsvString(line);
                    if (entry != null) {
                        timeEntries.add(entry);
                        System.out.println("Loaded: " + entry.getEmployeeNumber());
                    } else {
                        System.err.println("Skipped invalid line: " + line);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading time entries:");
            e.printStackTrace();
        }

        System.out.println("Total entries loaded: " + timeEntries.size());
    }

    public static void saveTimeEntries() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TIME_ENTRIES_FILE))) {
            for (TimeEntry entry : timeEntries) {
                writer.write(entry.toCsvString());
                writer.newLine();
            }
            System.out.println("All time entries saved to: " + TIME_ENTRIES_FILE.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error saving time entries: " + e.getMessage());
        }
    }

    public static boolean isClockedIn(String employeeNumber) {
        for (int i = timeEntries.size() - 1; i >= 0; i--) {
            TimeEntry entry = timeEntries.get(i);
            if (entry.getEmployeeNumber().equals(employeeNumber)) {
                return entry.getTimeOut() == null;
            }
        }
        return false;
    }

    public static void clockIn(String employeeNumber) {
        TimeEntry entry = new TimeEntry(employeeNumber, LocalDateTime.now());
        timeEntries.add(entry);
        saveTimeEntries();
        System.out.println("Clocked in: " + employeeNumber + " @ " + entry.getTimeIn());
    }

    public static void clockOut(String employeeNumber) {
        for (int i = timeEntries.size() - 1; i >= 0; i--) {
            TimeEntry entry = timeEntries.get(i);
            if (entry.getEmployeeNumber().equals(employeeNumber) && entry.getTimeOut() == null) {
                entry.setTimeOut(LocalDateTime.now());
                saveTimeEntries();
                System.out.println("Clocked out: " + employeeNumber + " @ " + entry.getTimeOut());

                SwingUtilities.invokeLater(() -> {
                    JDialog dialog = new JDialog();
                    dialog.setTitle("Employee Time Entries");
                    dialog.setSize(700, 400);
                    dialog.setModal(true);
                    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

                    JPanel panel = new JPanel();
                    PayrollService.displayTimeEntryTable(panel);
                    dialog.setContentPane(panel);
                    dialog.setLocationRelativeTo(null);
                    dialog.setVisible(true);
                });

                return;
            }
        }
        System.out.println("No open clock-in found for: " + employeeNumber);
    }

    public static List<TimeEntry> getTimeEntries() {
        return timeEntries;
    }

    public static List<TimeEntry> getTimeEntriesForEmployee(String employeeNumber) {
        List<TimeEntry> result = new ArrayList<>();
        for (TimeEntry entry : timeEntries) {
            if (entry.getEmployeeNumber().equals(employeeNumber)) {
                result.add(entry);
            }
        }
        return result;
    }

    public static double getTotalHoursForMonth(String employeeNumber, int year, int month) {
        double total = 0.0;
        for (TimeEntry entry : timeEntries) {
            if (entry.getEmployeeNumber().equals(employeeNumber)) {
                LocalDateTime timeIn = entry.getTimeIn();
                if (timeIn.getYear() == year && timeIn.getMonthValue() == month) {
                    total += entry.getHoursWorked();
                }
            }
        }
        return total;
    }
}
